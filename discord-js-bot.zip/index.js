//This is the MAIN FILE of your Discord Bot. Without it, nothing is possible.
//I have made a command and event handler, just to make everything more organized.
//Check the config.json to edit your token and prefix for the bot.


//Start With A fresh powershell or prompt
console.clear();
//require only the necessary objects from the modules
const { Client, Collection } = require('discord.js');
const { readdirSync, writeFileSync } = require('fs');
const { token, prefix } = require('./config.json');
const client = new Client();
//create two Collections to store our data
client.commands = new Collection();
client.aliases = new Collection();

//read the contents of the commands folder
for (let folder of readdirSync(`${__dirname}/commands/`)) {
    switch (folder) {
        //check the activities subfolder
        case "activities":
            for (let file of readdirSync(`${__dirname}/commands/${folder}/`)) {
                //make sure that only JavaScript files exist to prevent problems
                if (!file.endsWith(".js")) return;
                //get name of command
                let name = file.split(".")[0];
                try {
                    //notify the user we are loading the command
                    console.log(`Loading ${prefix}${name} from ${folder}`);
                    //import the command
                    let props = require(`./commands/${folder}/${name}`);
                    //add the data to our collections for later use
                    client.commands.set(name, props);
                    if (props.conf && props.conf.aliases) {
                        props.conf.aliases.forEach(alias => {
                            client.aliases.set(alias, name);
                        });
                    }
                }
                //if something went wrong
                catch (e) {
                    //notify the user about the command
                    console.log(e)
                }
            };
            break;
        //repeat for the rest of the subfolders and commands
        case "information":
            for (let file of readdirSync(`${__dirname}/commands/${folder}/`)) {
                if (!file.endsWith(".js")) return;
                let name = file.split(".")[0];
                try {
                    console.log(`Loading ${prefix}${name} from ${folder}`);
                    let props = require(`./commands/${folder}/${name}`);
                    client.commands.set(name, props);
                    if (props.conf && props.conf.aliases) {
                        props.conf.aliases.forEach(alias => {
                            client.aliases.set(alias, name);
                        });
                    }
                }
                catch (e) {
                    console.log(e)
                }
            };
            break;
        case "moderation":
            for (let file of readdirSync(`${__dirname}/commands/${folder}/`)) {
                if (!file.endsWith(".js")) return;
                let name = file.split(".")[0];
                try {
                    console.log(`Loading ${prefix}${name} from ${folder}`);
                    let props = require(`./commands/${folder}/${name}`);
                    client.commands.set(name, props);
                    if (props.conf && props.conf.aliases) {
                        props.conf.aliases.forEach(alias => {
                            client.aliases.set(alias, name);
                        });
                    }
                }
                catch (e) {
                    console.log(e)
                }
            };
            break;
        case "other":
            for (let file of readdirSync(`${__dirname}/commands/${folder}/`)) {
                if (!file.endsWith(".js")) return;
                let name = file.split(".")[0];
                try {
                    console.log(`Loading ${prefix}${name} from ${folder}`);
                    let props = require(`./commands/${folder}/${name}`);
                    client.commands.set(name, props);
                    if (props.conf && props.conf.aliases) {
                        props.conf.aliases.forEach(alias => {
                            client.aliases.set(alias, name);
                        });
                    }
                }
                catch (e) {
                    console.log(e)
                }
            };
            break;
        case "utility":
            for (let file of readdirSync(`${__dirname}/commands/${folder}/`)) {
                if (!file.endsWith(".js")) return;
                let name = file.split(".")[0];
                try {
                    console.log(`Loading ${prefix}${name} from ${folder}`);
                    let props = require(`./commands/${folder}/${name}`);
                    client.commands.set(name, props);
                    if (props.conf && props.conf.aliases) {
                        props.conf.aliases.forEach(alias => {
                            client.aliases.set(alias, name);
                        });
                    }
                }
                catch (e) {
                    console.log(e)
                }
            };
            break;
        //if none of the subfolders were found (optional)
        default:
            console.log('Nothing Found.')
    }
}

//check the files inside the events file
for (let file of readdirSync(`${__dirname}/events/`)) {
    //again, make sure that we are importing only js files
    if (!file.endsWith(".js")) return;
    const event = require(`./events/${file}`);
    //bind (or link) the file to the event
    client.on(file.split(".")[0], event.bind(null, client));
};
//I kept these events here for you so that you can edit them easily :D

/* Begin */
client.on('guildMemberAdd', member => {
    //if a user joins your server
    const channel = member.guild.channels.find(c => c.name === 'logs');
    channel.send(`${member.tag} just joined the server!`);
});
client.on('guildMemberRemove', member => {
    //if a user left your server
    const channel = member.guild.channels.find(c => c.name === 'logs');
    channel.send(`${member.tag} just left the server :(`)
})
/* End */

//Log the bot in using the token you copied
client.login(token);


//Check the Discord.JS Documentation if you ever get stuck :)
