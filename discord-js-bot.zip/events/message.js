//get the prefix of the bot
const { prefix } = require('../config.json');
module.exports = async (client, message) => {
    //make sure that we check for player messages only
    if (message.author.bot) return;
    var args;
    if (message.guild) {
        //if user sends message
        if (message.content.indexOf(prefix) !== 0) {
        }
        args = message.content.slice(prefix.length).trim().split(/ +/g);
    }
    else {
        //if user sends command
        args = message.content.slice(0).trim().split(/ +/g);
    }
    //requirements for command handler to work properly
    const command = args.shift().toLowerCase();
    if (message.guild && !message.member) await message.guild.fetchMember(message.author);
    const cmd = client.commands.get(command) || client.commands.get(client.aliases.get(command)); if (!cmd) return;
    cmd.run(client, message, args);
};