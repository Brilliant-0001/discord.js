module.exports = (client, message, args) => {
    //set Status mode
    client.user.setStatus('online');
    //set Presence information
    client.user.setPresence({
        game: {
            name: "a cool game",
            type: "PLAYING"
        }
    })

}
//Check the Discord.JS Documentation if you ever get stuck :)
