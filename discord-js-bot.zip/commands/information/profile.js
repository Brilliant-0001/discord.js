//this is an example to show you how to make a command!

//require the RichEmbed object from the discord.js module
const { RichEmbed } = require('discord.js');
exports.run = (client, message, args) => {
    //get the first mentioned user
    var user = message.mentions.users.first();
    //if no user mentioned, get the author info
    if (!user) user = message.author;

    //here is a proof of concept:

    //make an embed
    const embed = new RichEmbed()
    //set the author to the profile of the user's name
    .setAuthor(`${user.username}'s profile`, user.avatarURL)
    //customize it a bit
    .setColor('RANDOM')
    .setFooter(`Requested by ${user.username}`)
    .setTimestamp()
    .setThumbnail(user.avatarURL)
    //give some information!
    .addField('Full Username', user.tag)
    .addField('Created At', user.createdAt.toString().split(" ", 5).join(" "));
    //send the embed
    message.channel.send(embed);
}